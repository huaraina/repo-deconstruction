define(function(require) {
	let Test = require("../test.js");
	Formulas = require("../../src/scripts/Formulas.js");
	Test.table(function, [arguments], [expected values]);
});